module.exports = {
	// dbconnection:'mongodb://UsnKMSnsdmsnYAhn:12NKAsn23jednSjnsMNSi4@172.31.89.98:25149/stagcryCadksnejensd',
	dbconnection:'8f9ebe0acb539f5b82ae3a4aff9b55a7199f4b747ebb58ef460deb071169d42dd3d2b1fb51241cf5d8aa610cc537db97eb572c86f0a08a166a6555b92d3e0f58fc7ebb38425ae29676c6eeb6bbd77e4056cab785f1f8dcc7',
	port :2087,
	passPhrase : 'T1Bt0Lx5jA9ML6AJ8523IAv0anRd03Ya',
	algorithm : 'aes-256-ctr',
	jwtToken : 'CRYParCAde',
	iv : 'bLMjTTXPjUpWe345',
	Host : 'https://crypstagcade.crypcade.io/',	
	adminhost : 'https://crypadmincads.crypcade.io/#/0ec82d0ac9619f3c2a3ff2/',	
	redis_port:21468,
	redis_host:'172.31.89.98',
	redis_password:'UIOASbhodAOJsnalNA',	
	AWS_OPTIONS : {
 		accessKeyId: 'AKIA2SJQLZSXUC6S7DXB',
 		secretAccessKey: '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',
 		region:'us-east-1'
	},
	tronEnv:'https://api.shasta.trongrid.io',
	tronEvent: 'https://api.shasta.trongrid.io',
	tronKey:'80c9e00ec20fc804cfb95a5aa0e428c316d84a213fe033961b51e1541616fa5f9588b3f103201ca9bba23e19eb4dbbc6ba762ad5f1eadf1221695aae77300c5b',
	tronmintKey:'d497e455c103ce5798e0580ba4e67ac111d54b2d6bb730991a06b5001b44fd0f948fb7f00e714da3b8f96c1eb11db8cee92025d0a6badd1f71385bae2062015b',
	redisdata:{port:21468,host:'172.31.89.98',password:'UIOASbhodAOJsnalNA'},
	
}

var environ = 'prod';
module.exports = require("./"+environ+".js");